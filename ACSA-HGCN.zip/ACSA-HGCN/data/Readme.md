The rest_2015_test_target.tsv and rest_2015_test_notarget.tsv are Explicit Aspects test set and Implicit Aspect set, respectively.
